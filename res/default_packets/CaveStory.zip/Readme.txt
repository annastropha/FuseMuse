<Cave Story ~ Doukutsu Monogatari> (C) Studio Pixel 2004

Doukutsu.exe - Main Game Program
DoConfig.exe - Game Configuration utility
Manual.html - Explains the game's mechanics and troubleshooting options
Profile.dat - Save data (appears after first save.)

This program is freeware.
Neither Studio Pixel nor Aeon Genesis is responsible if it does Bad Things to your computer.
(Of course, it shouldn't, but that's beside the point.)

Here is the address of the author's homepage.
http://hp.vector.co.jp/authors/VA022293/

--The map is not usable unless you have the "Map System" item.
--If you have problems with getting two arrow keys to work at once, please use the < > ? settings.
--Please use Courier New as the font. Others cannot be guaranteed to work.
--If the keyboard controls are not responding, please disable "Use Gamepad" through DoConfig.exe.