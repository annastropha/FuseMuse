import sys

for line in sys.stdin:
  print(line)
  
sys.exit(0)
