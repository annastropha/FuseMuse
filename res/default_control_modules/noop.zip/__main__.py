import sys

sys.stdin.readline() # skip mode

for line in sys.stdin:
  print(line)
  
sys.exit(0)
